/**
 * Created by hasee on 2017/2/3.
 */
var http = require("http");
var files = require("./views/files");

http.createServer(function (request,response) {

    if(request.url!="/favicon.ico"){

        response.writeHead("200",{'Content-Type':'text/html;charset=utf-8'});
        files.writeFile(response); //异步的程序
    }

}).listen("8000");
console.log("server run at http://localhost:8000");