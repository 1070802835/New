/**
 * Created by hasee on 2017/2/3.
 */
module.exports={
  "name":"module2"
};