/**
 * Created by hasee on 2017/2/3.
 */

var m2 = require("./module2");

var m1 = {
    name:"module1",
    m2:m2
};

module.exports=m1;