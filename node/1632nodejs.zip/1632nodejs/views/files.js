/**
 * Created by hasee on 2017/2/3.
 */
//对外提供对文件操作的方法
var fs = require("fs");

module.exports={
    readFile:function (url,response) {
       fs.readFile(url,function (err,data) {
           //if(err) throw err;
           response.write(data);
           response.end()
       })
    },
    readImgFile:function (url,response) {
        //response.writeHead("200",{"Content-Type":'image/jpeg'});
        fs.readFile(url,'binary',function (err,data) {
            response.write(data,'binary');
            response.end()
        })
    },


    readFileSync:function (response) {
         var data = fs.readFileSync("./template/login.html");
         response.write(data);
         response.end()
    },
    writeFile:function (response) {
        fs.writeFile('./write/test.txt',"aassssaaaaa",function (err) {
            response.write("写入成功");
            response.end();
        })
    }
};