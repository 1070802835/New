/**
 * Created by hasee on 2017/2/3.
 */
var http = require("http");
var url = require("url");
var queryString = require("querystring")
var routes = require("./views/routes");

http.createServer(function (request,response) {

    if(request.url!="/favicon.ico"){

        //get 方式 用到了 url
       /* var urlObject =  url.parse(request.url,true);//可以把url字符串转换为url对象
        console.log(urlObject.query);*/

       //post 方式 用到了 querystring
        var postData = '';
        //当用post方式传参的时候
        request.on("data",function (chunk) {
            postData+=chunk;
        });

        request.on("end",function () {
            console.log(postData);
            console.log(queryString.parse(postData))//使用queryString格式化post的参数
        });

        var urlArr = request.url.split("/");
        //把url拆分成 数组
        //console.log(urlArr);
        //判断数组的第一项是不是html文件
       // console.log(urlArr[1].indexOf('.html'));
        //var reg = /.+\.html$/;
        if(urlArr[1].indexOf('.html')!=-1){


            //要请求的是html文件
            routes.html(urlArr[1],response)

        }else if(urlArr[1]=="images"){
            //要请求的是图片文件
            routes.images(urlArr[2],response)
        }else {
            //response.write("不是有效的html,显示首页的内容");
            routes.html("index.html",response);
            //response.end();
        }


    }

}).listen("8000");

console.log("server run at http://localhost:8000");