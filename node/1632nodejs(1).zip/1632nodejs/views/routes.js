/**
 * Created by hasee on 2017/2/3.
 */


var files = require("./files");

module.exports = {

    images:function (url,response) {
        files.readImgFile("./images/"+url,response)
    },
    //所有的html请求
    html:function (url,response) {
        response.writeHead("200",{'Content-Type':'text/html;charset=utf-8'});

        if(url.indexOf("?")!=-1){
            url = url.split("?")[0];
        }

        files.readFile("./template/"+url,response)
    }/*,

    home:function (response) {
        files.readFile("./template/index.html",response)
    },
    login:function (response) {
        files.readFile("./template/login.html",response)
    }*/
};