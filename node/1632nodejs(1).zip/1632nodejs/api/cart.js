/**
 * Created by hasee on 2017/2/4.
 */
var mysql = require('mysql');
module.exports={
    list:function (res,params) {
        //链接数据库配置
        var connection = mysql.createConnection({
            host:'localhost',
            user:'root',
            password:'root',
            database:'super1632',
            port:'3306'
        });
        connection.connect(function (err) {
            if(err){
                console.log('log: '+err)
            }else {
                console.log("[connection connect] success");
            }
        });

        connection.query('select * from cart where uid='+params.uid,function (err,results) {
            var data = JSON.stringify(results);
            console.log(data);
            res.write(data);
            res.end();
            connection.end(function (err) {
                if(err){
                    console.log('log: '+err)
                }else {
                    console.log("[connection end] success");
                }
            });
        });
    },
    addCart:function (res,params) {

        //如果加入购物车的时候要做商品数量的累加
        //1查：(查)查看当前用户有没有天加过此商品
        //2添加过：(改) 修改数量，让数量累加
        //3没有添加过: (增) 添加一条购物车信息

        //链接数据库配置
        var connection = mysql.createConnection({
            host:'localhost',
            user:'root',
            password:'root',
            database:'super1632',
            port:'3306'
        });
        connection.connect(function (err) {
            if(err){
                console.log('log: '+err)
            }else {
                console.log("[connection connect] success");
            }
        });

        connection.query('insert into cart(pid,uid,number) values('+params.pid+','+params.uid+',1)',function (err,results) {
            if(err){
                res.write("addCart err");
                console.log('log: '+err)
            }else {
                res.write("addCart success")
                console.log("addCart success");
            }
            res.end()
        });

        connection.end(function (err) {
            if(err){
                console.log('log: '+err)
            }else {
                console.log("[connection end] success");
            }
        });

    }
};