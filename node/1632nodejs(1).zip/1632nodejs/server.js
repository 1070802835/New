/**
 * Created by hasee on 2017/2/3.
 */
var http = require("http");
var m1 = require("./commonjs/module1");
http.createServer(function (request,response) {

    if(request.url!="/favicon.ico"){

        response.writeHead("200",{'Content-Type':'text/html;charset=utf-8'});
        console.log(request.url);//请求的地址
        response.write("hello nodejs");
        response.end()
    }

}).listen("8000");
console.log("server run at http://localhost:8000");