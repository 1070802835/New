/**
 * Created by hasee on 2017/2/4.
 */
var mysql = require('mysql');
var http = require('http');
var url = require('url');
var product = require("./api/product");
var cart = require("./api/cart");

http.createServer(function (req,res) {
    if(req.url!="/favicon.ico"){
       /* res.write("mysql");
        res.end();*/
        var urlArr = req.url.split('/');
        if(urlArr[1]=='api'){
            //console.log(urlArr)
            var pathObj = url.parse(urlArr[2],true);
            var params  = pathObj.query;//get方式的参数
            switch (pathObj.pathname){
                case 'product':
                    if(params.pid){
                        //如果有pid，说明前端想要请求商品的详情信息
                        product.getDetail(res,params.pid)
                        //把res 和商品id传给商品模块
                    }else {
                        //调用列表方法，把res，和参数传给商品模块
                        product.getList(res,params);
                        //res   ,params={page：1,linenumber：10,pid：2}
                    }
                    break;
                case 'cart':
                    //链接数据库配置
                    cart[params.type](res,params);
                    break;
                case 'user':
                    break;
                default:
                    res.write('无效的api接口');
                    res.end();
                    break;
            }

        }

        //创建连接
       /* connection.connect(function (err) {
            if(err){
                console.log('log: '+err)
            }else {
                console.log("[connection connect] success");
            }
        });
        //数据库请求
        connection.query("select * from product",function (err,results) {
            //console.log(results);
            var data = JSON.stringify(results);
            //把请求到的数据输出给前端
            res.write(data);//write的第一个参数必须是字符串
            res.end();
        });
        //关闭数据库连接
        connection.end(function (err) {
            if(err){
                console.log('log: '+err)
            }else {
                console.log("[connection end] success");
            }
        });*/

    }

}).listen('8000');
console.log("server run at http://localhost:8000");





/*

//打开数据库链接
connection.connect(function (err) {
    if(err){
        console.log('log: '+err)
    }else {
        console.log("[connection connect] success");
    }
});

//访问数据库
connection.query("select * from user",function (err,results) {
    console.log(results)
    //关闭链接
    connection.end(function (err) {
        if(err){
            console.log('log: '+err)
        }else {
            console.log("[connection end] success");
        }
    });
});

*/

